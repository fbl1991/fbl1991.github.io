<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/28/17
 * Time: 10:39 PM
 */

namespace common\component;


use yii\base\Component;

class Hook extends Component {

    const TEST = 'test';
}