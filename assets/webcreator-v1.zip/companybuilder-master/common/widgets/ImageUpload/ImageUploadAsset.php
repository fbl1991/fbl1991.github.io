<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/21/17
 * Time: 7:17 PM
 */

namespace common\widgets\ImageUpload;


use yii\web\AssetBundle;

class ImageUploadAsset extends AssetBundle {

    public $sourcePath = '@common/widgets/ImageUpload';

    public $js = [
        'js/upload.js',
    ];

    public $css = [
        'css/image.css',
    ];
}