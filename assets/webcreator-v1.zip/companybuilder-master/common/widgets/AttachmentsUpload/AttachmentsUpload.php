<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/22/17
 * Time: 8:53 PM
 */

namespace common\widgets\AttachmentsUpload;


use yii\base\Widget;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

class AttachmentsUpload extends Widget {

    public $form;
    public $model;
    public $attribute = 'imageFiles[]';
    public $action;

    public function run(){

        echo $this->form->field($this->model, $this->attribute)->fileInput(['multiple' => true,
            'accept' => 'image/*', 'id'=>'upload-attachment-input']);

    }
}