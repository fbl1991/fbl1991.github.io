<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/22/17
 * Time: 9:00 PM
 */

namespace common\widgets\AttachmentsUpload;


class AttachmentsUploadAsset {

}