<?php
Yii::setAlias('@localhost','http://localhost/yii2');
Yii::setAlias('@common', dirname(__DIR__));
Yii::setAlias('@commonurl',Yii::getAlias('@localhost').'/common');

Yii::setAlias('@vendorurl',Yii::getAlias('@localhost').'/vendor');
Yii::setAlias('@sysimg',Yii::getAlias('@commonurl') . '/upload/system');
Yii::setAlias('@frontend', dirname(dirname(__DIR__)) . '/frontend');
Yii::setAlias('@frontendurl',Yii::getAlias('@localhost') . '/frontend');

Yii::setAlias('@backend', dirname(dirname(__DIR__)) . '/backend');

Yii::setAlias('@backendurl', Yii::getAlias('@localhost'). '/backend');

Yii::setAlias('@console', dirname(dirname(__DIR__)) . '/console');
