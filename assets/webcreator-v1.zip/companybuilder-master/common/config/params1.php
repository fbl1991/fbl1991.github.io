<?php 
 return array (
  'adminEmail' => 'admin@example.com',
  'supportEmail' => 'support@example.com',
  'user.passwordResetTokenExpire' => 3600,
  'newsSwitch' => true,
  'newsCommentSwitch' => true,
  'goodsSwitch' => true,
  'webName' => '一个站点sadasa',
);