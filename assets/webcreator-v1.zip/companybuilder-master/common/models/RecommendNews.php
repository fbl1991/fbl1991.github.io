<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "{{%recommend_news}}".
 *
 * @property integer $id
 * @property integer $newsId
 * @property integer $rate
 */
class RecommendNews extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%recommend_news}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['newsId'], 'required'],
            [['newsId', 'rate'], 'integer'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'newsId' => 'News ID',
            'rate' => 'Rate',
        ];
    }

    /**
     * @inheritdoc
     * @return RecommendNewsQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new RecommendNewsQuery(get_called_class());
    }
}
