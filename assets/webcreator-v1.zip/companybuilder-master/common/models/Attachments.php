<?php

namespace common\models;

use mongosoft\file\UploadBehavior;
use Yii;

/**
 * This is the model class for table "{{%attachments}}".
 *
 * @property integer $id
 * @property string $identityId
 * @property string $fileName
 * @property string $url
 */
class Attachments extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%attachments}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['fileName'], 'required'],
            [['fileName'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'ownerId' => '拥有者 ID',
            'fileName' => '文件原名',
            'url' => '访问路由',
            'savePath' => '保存路径',
        ];
    }

    /**
     * @inheritdoc
     * @return AttachmentsQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new AttachmentsQuery(get_called_class());
    }

    public function afterDelete() {

        if(is_file($this->savePath . DIRECTORY_SEPARATOR.$this->url)){
            unlink($this->savePath . DIRECTORY_SEPARATOR.$this->url);
        }
        return true;
    }

}
