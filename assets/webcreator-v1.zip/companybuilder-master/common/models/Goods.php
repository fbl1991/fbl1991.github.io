<?php

namespace common\models;

use common\behaviors\AttachmentsBehavior;
use common\behaviors\UploadFilesBehavior;
use Yii;
use yii\behaviors\TimestampBehavior;

/**
 * This is the model class for table "{{%goods}}".
 *
 * @property integer $id
 * @property string $title
 * @property string $price
 * @property string $front_img
 * @property integer $created_at
 * @property integer $updated_at
 * @property integer $status
 */
class Goods extends \yii\db\ActiveRecord
{
    const STATUS_UNPUBLISH = 0;
    const STATUS_PUBLISH =1;
    const STATUS_UNDERCARRIAGE = 2;

    public $attachmentsToBe;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%goods}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'price',  'status', 'briefIntro'], 'required'],
            [[ 'status'], 'integer'],
            ['info','string'],
            ['briefIntro','string', 'max' => 32],
            ['status','in', 'range'=>[static::STATUS_PUBLISH, static::STATUS_UNDERCARRIAGE, static::STATUS_UNPUBLISH]],
            [['title', 'price'], 'string', 'max' => 255],
            [['price', 'originalPrice'], 'double'],
            ['front_img', 'image', 'extensions' => 'jpg, jpeg, gif, png', 'on' => ['create', 'update']],
            ['front_img', 'required', 'on'=>'create'],
            ['attachmentsToBe', 'file', 'extensions' => 'doc, docx, pdf','maxFiles' => 5],

        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => '名称',
            'price' => '价格',
            'originalPrice' => '原价',
            'front_img' => '首页图片',
            'created_at' => '创建时间',
            'updated_at' => '更新时间',
            'status' => '状态',
            'info' => '详情',
            'briefIntro' => '一句话介绍',
            'attachments' => '附件',
            'attachmentsToBe' => '待传附件',
        ];
    }



    /**
     * @inheritdoc
     * @return GoodsQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new GoodsQuery(get_called_class());
    }

    /**
     * @return array
     */
    public function behaviors() {
        return [
            TimestampBehavior::className(),
            [
                'class' => \mongosoft\file\UploadImageBehavior::className(),
                'attribute' => 'front_img',
                'scenarios' => ['create', 'update'],
                'placeholder' => '@common/upload/placeholder.jpg',
                'path' => '@common/upload/user/{id}',
                'url' => '@commonurl/upload/user/{id}',
                'thumbs' => [
                    'thumb' => ['width' => 319, 'height'=>200,'quality' => 90],
                    'preview' => ['width' => 319, 'height' => 200],
                ],
            ],
            [
                'class' => AttachmentsBehavior::className(),
                'uploadFiles' => 'attachmentsToBe',
                'uploadedFiles' => 'attachments',
            ],
        ];
    }
}
