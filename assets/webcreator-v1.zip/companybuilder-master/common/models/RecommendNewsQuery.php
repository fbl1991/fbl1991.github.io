<?php

namespace common\models;

/**
 * This is the ActiveQuery class for [[RecommendNews]].
 *
 * @see RecommendNews
 */
class RecommendNewsQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        return $this->andWhere('[[status]]=1');
    }*/

    /**
     * @inheritdoc
     * @return RecommendNews[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * @inheritdoc
     * @return RecommendNews|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
