<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/20/17
 * Time: 8:32 PM
 */

namespace common\actions;


use Yii;
use yii\base\Action;
use yii\base\InvalidConfigException;
use yii\helpers\FileHelper;
use yii\helpers\Json;
use yii\helpers\Url;
use yii\web\UploadedFile;

class UploadFileAction extends Action {

    public $model;
    public $attribute = 'image';
    public $directory = '@common/upload';
    public $baseUrl = '@commonurl/upload';


    public function init() {
        if($this->model == null){
            throw new InvalidConfigException('The "model" property must be set.');
        }
    }

    public function run(){
        $model = Yii::createObject($this->model);

        $imageFile = UploadedFile::getInstance($model, $this->attribute);

        $directory = Yii::getAlias($this->directory) . DIRECTORY_SEPARATOR . Yii::$app->session->id . DIRECTORY_SEPARATOR;
        if (!is_dir($directory)) {
            FileHelper::createDirectory($directory);
        }

        if ($imageFile) {
            $uid = uniqid(time(), true);
            $fileName = $uid . '.' . $imageFile->extension;
            $filePath = $directory . $fileName;
            if ($imageFile->saveAs($filePath)) {
                $path = Yii::getAlias($this->baseUrl) . Yii::$app->session->id . DIRECTORY_SEPARATOR . $fileName;
                return Json::encode([
                    'files' => [
                        [
                            'name' => $fileName,
                            'size' => $imageFile->size,
                            'url' => $path,
                            'thumbnailUrl' => $path,
                            'deleteUrl' =>  Url::to([$this->deleteUrl, 'name'=>$fileName]),
                            'deleteType' => 'POST',
                        ],
                    ],
                ]);
            }
        }

        return '';
    }
}