<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/28/17
 * Time: 10:37 PM
 */

namespace common\plugins;


use yii\base\Event;

class Test extends Event {

    public function hello(){
        echo 'hello';
    }
}

