<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/8/17
 * Time: 9:29 PM
 */

namespace backend\models;


use common\behaviors\RolesBehaviour;
use common\models\User as cuser;

class User extends cuser  {


    private $_isAdmin;
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return array_merge(
            parent::rules(),
            [['isAdmin','boolean']]
        );
    }

    public function getIsAdmin(){
        return $this->is('admin');
    }

    public function setIsAdmin($value){
        $this->_isAdmin = $value;
    }
    public function afterSave($insert, $changedAttributes) {
        parent::afterSave($insert, $changedAttributes);
        if($this->_isAdmin){
            $this->setRole('admin');
        }else{
            $this->unsetRole('admin');
        }

    }


    public function behaviors() {
        return [
            RolesBehaviour::className(),
        ];
    }

    public function attributeLabels() {
        return array_merge(
            parent::attributeLabels(),
            [
                'isAdmin' => '是否为管理员',
            ]
            );
    }
}