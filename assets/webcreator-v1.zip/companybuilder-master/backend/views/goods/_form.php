<?php

use common\models\Attachments;
use common\widgets\AttachmentsUpload\AttachmentsUpload;
use common\widgets\ImageUpload\ImageUpload;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use common\models\Goods;
/* @var $this yii\web\View */
/* @var $model common\models\Goods */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="goods-form">

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'price')->textInput(['maxlength' => true])->label('定价(元)') ?>

    <?= $form->field($model, 'originalPrice')->textInput(['maxlength' => true])->label('原价(元)') ?>

    <?= $form->field($model, 'briefIntro')->textInput(['maxlength' => true])->label() ?>

    <?= ImageUpload::widget([
        'form' => $form,
        'model' => $model,
        'attribute' => 'front_img',
    ])?>

    <?= $form->field($model, 'info')->widget(\yii\redactor\widgets\Redactor::className(),[
        'clientOptions' => [
            //'imageManagerJson' => ['/redactor/upload/image-json'],
            //'imageUpload' => ['/redactor/upload/image'],
            //'fileUpload' => ['/redactor/upload/file'],
            'lang' => 'zh_cn',
            'plugins' => ['clips', 'fontcolor','imagemanager']
        ]
    ])?>
    <?= $form->field($model, 'status')->dropDownList([Goods::STATUS_UNPUBLISH => '还没上架',
        Goods::STATUS_PUBLISH =>'上架',Goods::STATUS_UNDERCARRIAGE => '下架了']) ?>

    <?php
        foreach ($model->attachments as $attachment){
            echo "<div id='uploadedfiles-$attachment->id' class='upload-files'> ";
            echo Html::a($attachment->fileName, $model->getFilesUrl($attachment->url));
            $url = Url::to(["attachment/del",'id' => $attachment->id]);
            echo Html::button('删除',['onclick' => "
                (function(e){
                    $.ajax({
                        url: \"$url\",
                        type: 'POST',   
                        success: function(data){
                            $('#uploadedfiles-$attachment->id').remove();
                        }
                    });
                }())
            "]);
            echo '</div>';
        }
    ?>
    <?=  $form->field($model, 'attachmentsToBe[]')->fileInput(['multiple' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? '创建' : '更新',
            ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
