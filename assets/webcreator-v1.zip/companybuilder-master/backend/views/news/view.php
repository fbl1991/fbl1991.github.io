<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\News */

$this->title = $model->title;
$this->params['breadcrumbs'][] = ['label' => '新闻', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="news-view">

    <p>
        <?= Html::a('更新', ['update', 'id' => $model->id], ['class' => 'btn btn-primary btn-info']) ?>
        <?= Html::a('删除', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-warning',
            'data' => [
                'confirm' => '该操作不可恢复,确定删除?',
                'method' => 'post',
            ],
        ]) ?>
    </p>
    <h4>缩略图</h4>
    <div class="thumbnail">

       <?php
            echo $this->renderAjax('@frontend/web/themes/default/news/_newsList.php',
                        [
                            'model' => $model
                        ]
                    );
        ?>
    </div>
    <h4>详情</h4>
    <div class="detail">

        <?php
        echo $this->renderAjax('@frontend/web/themes/default/news/view.php',
            [
                'model' => $model
            ]
        );
        ?>
    </div>

</div>
