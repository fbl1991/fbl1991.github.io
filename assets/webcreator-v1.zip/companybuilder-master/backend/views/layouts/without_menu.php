<?php

/* @var $this \yii\web\View */
/* @var $content string */

use backend\assets\AppAsset;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use common\widgets\Alert;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<?php $this->title = '后台管理系统';?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body class=" without-menu">
<?php $this->beginBody() ?>
<div class="container">
    <div class="rows">
        <div class="col-lg-4 col-lg-offset-4  without-menu-content">
            <?= $content ?>
            <div class="shr_without-menu-content"></div>
            <div class="shl_without-menu-content"></div>
        </div>
    </div>

</div>




<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
