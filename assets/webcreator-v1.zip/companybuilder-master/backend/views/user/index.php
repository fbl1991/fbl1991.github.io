<?php

use common\models\User;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Users';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('添加用户', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
<?php Pjax::begin(); ?>    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'username',
             'email:email',
             'status',
            [
                'attribute'=>'status',
                'value' => function($model){
                    $status = [
                        User::STATUS_DELETED => '已停用',
                        User::STATUS_ACTIVE => '已激活',
                    ];
                    return $status[$model->status];
                },
                'filter' => [
                    User::STATUS_DELETED => '已停用',
                    User::STATUS_ACTIVE => '已激活',
                ],

            ],
             [
                'attribute'=> 'created_at',
                 'format' => ['date', 'php:Y-m-d'],
             ],
             [
                 'attribute' => 'updated_at',
                 'format' => ['date', 'php:Y-m-d'],
             ],
            [
                'attribute' => 'isAdmin',
                'value' => function($model){
                    return $model->is('admin')? '是':'否';
                },
            ],

            [
                'class' => 'yii\grid\ActionColumn'
            ],
        ],
    ]); ?>
<?php Pjax::end(); ?></div>
