<?php
/* @var $this yii\web\View */

$this->title = $model->title;
$this->registerCssFile('@frontendurl/web/css/news.css');
?>



<div class="news-pad">
    <h1 class="news-header"><?=$model->title;?></h1>
    <div class="news-author">
        <span>编辑: <?= $model->editor->username?></span>
        <span>作者: <?= $model->author?></span>
        <span>更新时间: <?=date('Y-m-d',$model->created_at);?></span>
    </div>
    <div class="news-body">
        <?php
            echo $model->content;
        ?>
    </div>

</div>
<?php if(isset(Yii::$app->params['newsCommentSwitch']) && Yii::$app->params['newsCommentSwitch']){
    echo $this->render('@frontend/web/themes/default/comment/_form',[
        'model' => $model,
    ]);
 }?>
