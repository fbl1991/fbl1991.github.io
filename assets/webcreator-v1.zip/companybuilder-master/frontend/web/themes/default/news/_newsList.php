<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 1/26/17
 * Time: 1:49 PM
 */

 use yii\bootstrap\Html;
use yii\helpers\Url;

$this->registerCssFile('@frontendurl/web/css/news.css');
?>

<div class="media">
    <div class="media-left media-middle col-lg-3">
        <a href="<?=Url::to(['news/view','id'=>$model->id])?>">
            <?= Html::img($model->getThumbUploadUrl('frontImg'), ['class' => 'media-object img-rounded img-responsive']);?>
        </a>
    </div>
    <div class="media-body">
        <h4 class="media-heading">
            <?= Html::a($model->title, Url::to(['news/view','id'=>$model->id]))?>
        </h4>

        <div class="media-author">
            <span> 作者:<?=$model->author?></span>
            <span> 更新时间:<?= date('Y-m-d', $model->updated_at)?></span>
        </div>
        <div>
            <?= $model->abstract?>
        </div>
    </div>
</div>
<HR style="border:1 dashed #987cb9" width="100%" color=#987cb9 SIZE=1>
