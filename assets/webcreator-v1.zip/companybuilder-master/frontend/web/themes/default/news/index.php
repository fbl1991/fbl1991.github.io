<?php
/* @var $this yii\web\View */
use yii\widgets\ListView;

$this->title = '新闻';
$this->registerCssFile('@frontendurl/web/css/news.css');
?>

<div class="col-lg-8">
    <div class="news-latest">最新资讯</div>
    <?= ListView::widget([
        'dataProvider' => $dataProvider,
        'emptyText' => '还没有大事儿发生……',
        'itemView' => '_newsList',
        'summary' => '',
    ]);?>
</div>
<div class="col-lg-3">
    <?php
        Yii::$app->trigger('news_index_hot');
    ?>
    <ul class="list-group">热门新闻

        <li class="list-group-item">
            <span class="badge">14</span>
            Cras justo odio
        </li>
        <li class="list-group-item">
            <span class="badge">14</span>
            Cras justo odio
        </li>
        <li class="list-group-item">
            <span class="badge">14</span>
            Cras justo odio
        </li>
    </ul>
    <ul class="list-group">推荐阅读
        <li class="list-group-item">
            <span class="badge">14</span>
            Cras justo odio
        </li>
        <li class="list-group-item">
            <span class="badge">14</span>
            Cras justo odio
        </li>
        <li class="list-group-item">
            <span class="badge">14</span>
            Cras justo odio
        </li>
    </ul>
</div>




