<?php

/* @var $this \yii\web\View */
/* @var $content string */

use frontend\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<?php
echo $this->render('_head.php');
?>
<body>
<?php $this->beginBody() ?>

<div class="wrap">
    <?php
    echo $this->render('_menu.php');
    ?>
    <div class="container col-lg-8 col-lg-offset-2 main-width-8">
        <?= $content ?>
    </div>



</div>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
