<?php
use common\component\Hook;
use common\plugins\Test;
use yii\base\Event;

Event::on(Hook::className(),Hook::TEST,[new Test(), 'hello']);