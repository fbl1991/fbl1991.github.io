<?php

use yii\db\Migration;

class m170220_110824_add_front_page_to_news extends Migration
{
    public function up()
    {

        $this->addColumn('{{%news}}', 'frontImg', 'string');
        $this->addCommentOnColumn('{{%news}}', 'frontImg', '首页图片');
    }

    public function down()
    {
        $this->dropColumn('{{%news}}', 'frontImg');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
