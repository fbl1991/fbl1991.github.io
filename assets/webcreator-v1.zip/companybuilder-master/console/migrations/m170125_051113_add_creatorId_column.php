<?php

use yii\db\Migration;

class m170125_051113_add_creatorId_column extends Migration
{
    public function up()
    {

        $this->addColumn('{{%news}}', 'userId', 'int(11) not null');
        $this->addCommentOnColumn('{{%news}}','userId','用户ID');
        //$this->addForeignKey('fk_userId','{{%news}}','userId','{{%user}}','id','SET NULL');
    }

    public function down()
    {
        //$this->dropForeignKey('fk_userId','{{%news}}');
        $this->dropColumn('{{%news}}', 'userId');
        return false;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
