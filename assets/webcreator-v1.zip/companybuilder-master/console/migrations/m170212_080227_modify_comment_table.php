<?php

use yii\db\Migration;

class m170212_080227_modify_comment_table extends Migration
{
    public function up()
    {
        $this->delete('{{%comment}}');
        $this->dropColumn('{{%comment}}', 'newsId');
        $this->addColumn('{{%comment}}', 'ownerId','string not null');
        $this->addColumn('{{%comment}}', 'status', 'smallint not null');
        $this->addColumn('{{%comment}}', 'senderId', 'int(11) not null');
        $this->addColumn('{{%comment}}', 'receiverId', 'int(11) not null');
        $this->addColumn('{{%comment}}', 'sendStatus', 'smallint not null');

        $this->addCommentOnColumn('{{%comment}}', 'ownerId','评论对象的Id,如news.Id');
        $this->addCommentOnColumn('{{%comment}}', 'status', '评论的状态,用于审核');
        $this->addCommentOnColumn('{{%comment}}', 'senderId', '发送者的Id');
        $this->addCommentOnColumn('{{%comment}}', 'receiverId', '发送者的Id');
        $this->addCommentOnColumn('{{%comment}}', 'sendStatus', '是否已阅');

    }

    public function down()
    {

        $this->dropColumn('{{%comment}}', 'ownerId');
        $this->dropColumn('{{%comment}}', 'status');
        $this->dropColumn('{{%comment}}', 'senderId');
        $this->dropColumn('{{%comment}}', 'receiverId');
        $this->dropColumn('{{%comment}}', 'sendStatus');
        return true;
    }


}
