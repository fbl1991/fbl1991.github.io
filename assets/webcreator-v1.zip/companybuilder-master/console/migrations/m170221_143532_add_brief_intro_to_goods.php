<?php

use yii\db\Migration;

class m170221_143532_add_brief_intro_to_goods extends Migration
{
    public function up()
    {

        $this->addColumn('{{%goods}}', 'briefIntro', 'string');
        $this->addCommentOnColumn('{{%goods}}', 'briefIntro', '一句话介绍');
    }

    public function down()
    {
        $this->dropColumn('{{%goods}}','briefIntro');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
