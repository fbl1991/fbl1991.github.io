<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/7/17
 * Time: 8:18 PM
 */

namespace common\behaviors;


use common\models\Roles;
use yii\base\Behavior;

class RolesBehaviour extends Behavior {

    public $role = '';
    /**
     * 查看是否为某个角色
     * @param $role
     * @return null|static
     */
    public function is($role){
        return Roles::hasRole($this->owner->id, $role);
    }

    /**
     * 增加某个角色
     * @param $role
     * @return bool
     */
    public function setRole($role){
        return Roles::addRole($this->owner->id, $role);
    }

    /**
     * 删除角色
     * @param $role
     * @return bool
     */
    public function unsetRole($role){
        return Roles::deleteRole($this->owner->id, $role);
    }


}