<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "{{%like}}".
 *
 * @property integer $id
 * @property string $identityId
 * @property integer $userId
 */
class Like extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%like}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['identityId', 'userId'], 'required'],
            [['userId'], 'integer'],
            [['identityId'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'identityId' => 'Identity ID',
            'userId' => 'User ID',
        ];
    }

    /**
     * @inheritdoc
     * @return LikeQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new LikeQuery(get_called_class());
    }
}
