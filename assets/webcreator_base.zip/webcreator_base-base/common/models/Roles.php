<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/7/17
 * Time: 8:22 PM
 */

namespace common\models;


use yii\db\ActiveRecord;

class Roles extends ActiveRecord {


    public static function tableName() {
        return '{{%roles}}';
    }

    public function rules(){
        return [
            ['userId', 'integer'],
            ['role', 'string'],
        ];
    }

    /*
     * 增加一个角色
     * */
    public static function addRole($userId, $role){
        if(static::hasRole($userId, $role) == false){
            $model = new Static;
            $model->userId = $userId;
            $model->role = $role;
            return $model->save();
        }
        return true;
    }

    /**
     * 删除角色
     * @param $userId
     * @param $rolo
     * @return bool
     */
    public static function deleteRole($userId, $role){
        $models = static::find()->where(['userId'=>$userId, 'role'=>$role])->all();
        if(!empty($models)){
            foreach ($models as $model){
                $model->delete();
            }
        }
        return true;
    }

    /**
     * 查看角色是否存在
     * @param $userId
     * @param $role
     * @return null|static
     */
    public static function hasRole($userId, $role){
        $model =  static::findOne(['userId'=>$userId, 'role'=>$role]);
        return $model !== null;
    }
}