<?php

namespace common\models;

use Yii;
use yii\behaviors\TimestampBehavior;

/**
 * This is the model class for table "{{%comment}}".
 *
 * @property integer $id
 * @property integer $newsId
 * @property string $content
 * @property integer $userId
 */
class Comment extends \yii\db\ActiveRecord
{
    const STATUS_PUBLISHED = 1;  /*允许发表*/
    const STATUS_REJECTED = 0;  // 拒绝发表

    const SENDSTATUS_RECEIVED = 1;  //已接收
    const SENDSTATUS_UNRECEIVED = 0; //未接收

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%comment}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ownerId', 'content', 'status',  'receiverId', 'link'], 'required'],
            [['receiverId'], 'integer'],
            [['content', 'ownerId'], 'string','max'=>255],
            ['status','in','range'=>[self::STATUS_PUBLISHED, self::STATUS_REJECTED]],
        ];
    }

    public function beforeSave($insert) {
        if(parent::beforeSave($insert)){
            if($this->isNewRecord) {
                $this->sendStatus =  self::SENDSTATUS_UNRECEIVED;
                $this->senderId = Yii::$app->user->id;
                    return true;
            }
            return true;
        }else{
            return false;
        };
    }


    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'newsId' => '新闻ID',
            'content' => '内容',
            'senderId' => '发送者ID',
            'receiverId' => '接收者ID',
            'status' => '审核状态',
            'sendStatus' => '发送状态',
            'link' => '链接地址',
            'created_at' => '创建时间',
            'updated_at' => '更新时间',
        ];
    }

    /**
     * 获得发送者
     * @return \yii\db\ActiveQuery
     */
    public function getSender(){
        return $this->hasOne(User::className(), ['id'=>'senderId']);
    }

    /**
     * 获得接收者
     * @return \yii\db\ActiveQuery
     */
    public function getReceiver(){
        return $this->hasOne(User::className(), ['id' => 'receiverId']);
    }
    /**
     * @inheritdoc
     * @return CommentQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new CommentQuery(get_called_class());
    }


    public function behaviors() {
        return array_merge(
            parent::behaviors(),
            [
                'class'=>TimestampBehavior::className(),
            ]

        );
    }
}
