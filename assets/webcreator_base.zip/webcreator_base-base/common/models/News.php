<?php

namespace common\models;

use Yii;
use yii\behaviors\TimestampBehavior;

/**
 * This is the model class for table "{{%news}}".
 *
 * @property integer $id
 * @property string $title
 * @property string $author
 * @property string $content
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 */
class News extends \yii\db\ActiveRecord
{
    const STATUS_DRAFT = 0;
    const STATUS_PUBLISH = 1;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%news}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'author', 'content', 'abstract'], 'required'],
            [['content'], 'string'],
            [['status'], 'integer'],
            [['title', 'abstract'], 'string', 'max' => 255],
            [['author'], 'string', 'max' => 32],
            ['frontImg', 'image', 'extensions' => 'jpg, jpeg, gif, png', 'on' => ['create', 'update']],
            ['frontImg', 'required', 'on'=>'create'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => '标题',
            'userId' => '创建者ID',
            'author' => '作者',
            'content' => '内容',
            'status' => '状态',
            'created_at' => '创建时间',
            'updated_at' => '更新时间',
            'abstract' => '摘要',
            'frontImg' => '首页图片',
        ];
    }

    public function getEditor(){
        return $this->hasOne(User::className(),['id' => 'userId']);
    }

    public function getIdentityId(){
        return  self::className().'.'.$this->id;
    }

    public function getComments(){
        return $this->hasMany(Comment::className(),['ownerId' =>'identityId']);

    }
    /**
     * @inheritdoc
     * @return NewsQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new NewsQuery(get_called_class());
    }

    /**
     * 插入前设置编辑id
     * @param bool $insert
     * @return bool
     */
    public function beforeSave($insert) {
        if(parent::beforeSave($insert)){
            if($this->isNewRecord){
                $this->userId = Yii::$app->user->id;
                return true;
            }
            return true;
        }

        return false;
    }

    /**
     * 删除前将评论先删除
     */
    public function beforeDelete() {
        parent::beforeDelete();
        $comments = $this->comments;

        foreach ($comments as $key => $comment){
            $comment->delete();
        };

        return true;
    }

    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
            [
                'class' => \mongosoft\file\UploadImageBehavior::className(),
                'attribute' => 'frontImg',
                'scenarios' => ['create', 'update'],
                'placeholder' => '@common/upload/placeholder.jpg',
                'path' => '@common/upload/user/{id}',
                'url' => '@commonurl/upload/user/{id}',
                'thumbs' => [
                    'thumb' => ['width' => 400, 'quality' => 90],
                    'preview' => ['width' => 200, 'height' => 200],
                ],
            ],
        ];
    }
}
