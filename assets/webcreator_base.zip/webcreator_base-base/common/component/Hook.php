<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/28/17
 * Time: 10:39 PM
 */

namespace common\component;


use yii\base\Component;

class Hook extends Component {

    const TEST = 'test';
    const NEWS_HOT = 'news_hot';
    const NEWS_PROPOSE = 'news_propose';
    const NEWS_DISCUSSION = 'news_discussion';

    const GOODS_PROPOSE = 'goods_propose';
    const GOODS_DISCUSSION = 'goods_disscussion';


}