/**
 * Created by fbl on 2/22/17.
 */
(function ($) {
    
    $('#upload-attachment-input').on('change', function () {
        // Get a reference to the fileList
        var files = !!this.files ? this.files : [];

        // If no files were selected, or no FileReader support, return
        if (!files.length || !window.FileReader) return;


        // Create a new instance of the FileReader
        var reader = new FileReader();

        // Read the local file as a DataURL
        reader.readAsDataURL(files[0]);

        // When loaded, set image data as background of div
        reader.onloadend = function(){
            $('#upload-attachment-form').submit();
        }
    })

    $('#upload-attachment-form').submit(function(){

    });

}(jQuery));