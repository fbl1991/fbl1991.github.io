<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/20/17
 * Time: 10:29 PM
 */

namespace common\widgets\ImageUpload;


use yii\base\InvalidConfigException;
use yii\bootstrap\Widget;
use yii\helpers\Html;

class ImageUpload extends Widget {

    public $form;
    public $model;
    public $attribute;


    public function init() {
        parent::init();
        if(empty($this->form)){
            throw new InvalidConfigException('The $model attribute must be set');
        }
        if(empty($this->model)){
            throw new InvalidConfigException('The $model attribute must be set');
        }
        if(empty($this->attribute)){
            throw new InvalidConfigException('The $model attribute must be set');
        }

    }

    public function run(){
        $model = $this->model;
        echo $this->form->field($model, $this->attribute)->fileInput(['accept' => 'image/*', 'id'=>'upload-image']);
        echo Html::img($model->getThumbUploadUrl($this->attribute, 'preview'), ['class' => 'upload-preview','id'=>'upload-preview']);

        ImageUploadAsset::register($this->view);
    }
}