<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 3/4/17
 * Time: 10:33 AM
 */

namespace common\interfaces;


class DiscussionInterface {

    const EVENT_DISCUSSION = 'discussion';

}