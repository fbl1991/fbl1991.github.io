<?php 
 return array (
  'adminEmail' => 'admin@example.com',
  'supportEmail' => 'support@example.com',
  'user.passwordResetTokenExpire' => 3600,
  'newsSwitch' => '1',
  'newsCommentSwitch' => '1',
  'goodsSwitch' => '1',
  'webName' => '这是一个新站点',
  'editor' => 'ueditor',
  'friendLinks' => '',
  'logo' => NULL,
);