<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/10/17
 * Time: 10:04 PM
 */

namespace common\filters;


class AccessRule extends \yii\filters\AccessRule {

    /**
     * @param User $user the user object
     * @return boolean whether the rule applies to the role
     */
    protected function matchRole($user)
    {
        if (empty($this->roles)) {
            return true;
        }
        foreach ($this->roles as $role) {
            if ($role === '?') {
                if ($user->getIsGuest()) {
                    return true;
                }
            } elseif ($role === '@') {
                if (!$user->getIsGuest()) {
                    return true;
                }
            } elseif ($user->can($role)) {
                return true;
            } elseif ($role === '#') {
                if(!$user->getIsGuest() && $user->identity->is('admin')) {
                    return true;
                }
            }
        }

        return false;
    }
}