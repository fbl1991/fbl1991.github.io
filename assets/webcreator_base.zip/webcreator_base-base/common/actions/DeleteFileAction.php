<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/20/17
 * Time: 8:43 PM
 */

namespace common\actions;


use Yii;
use yii\base\Action;
use yii\helpers\FileHelper;
use yii\helpers\Json;

class DeleteFileAction extends Action {

    public $directory = '@common/upload';
    public $baseUrl = '@commonurl/upload';

    public function run($name){
        $directory = Yii::getAlias($this->directory) . DIRECTORY_SEPARATOR . Yii::$app->session->id;
        if (is_file($directory . DIRECTORY_SEPARATOR . $name)) {
            unlink($directory . DIRECTORY_SEPARATOR . $name);
        }

        $files = FileHelper::findFiles($directory);
        $output = [];
        foreach ($files as $file) {
            $fileName = basename($file);
            $path = Yii::getAlias($this->baseUrl) . Yii::$app->session->id . DIRECTORY_SEPARATOR . $fileName;
            $output['files'][] = [
                'name' => $fileName,
                'size' => filesize($file),
                'url' => $path,
                'thumbnailUrl' => $path,
                'deleteUrl' => 'image-delete?name=' . $fileName,
                'deleteType' => 'POST',
            ];
        }
        return Json::encode($output);
    }
}