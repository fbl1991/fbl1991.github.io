<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/22/17
 * Time: 11:34 PM
 */

namespace common\actions;


use yii\base\Action;

class DeleteAttachmentAction extends Action {

    public $owner;

    public function run($url, $ownerId){
        $model = ($this->owner)::findOne(['id' => $ownerId]);
        $model->deleteFile($url);
    }
}