<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 3/4/17
 * Time: 10:43 AM
 */

namespace common\plugins;


use common\models\News;
use yii\base\Event;
use yii\data\ActiveDataProvider;

class NewsEvent extends Event {

    public function showHotNews($event){
        $limit = isset($event->data['limit'])?$event->data['limit']:5;
        $hotNewsDataProvider = new ActiveDataProvider([
            'query' => News::find()->limit($limit),
        ]);
        $hotNews = $hotNewsDataProvider->getModels();
        foreach ($hotNews as $news){
            echo $news->id;
        }

    }
}