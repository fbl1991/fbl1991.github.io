<?php
/**
 * 显示热门消息
 * User: fbl
 * Date: 3/4/17
 * Time: 10:43 AM
 */

namespace common\plugins;


use common\models\News;
use yii\base\Event;
use yii\data\ActiveDataProvider;

class HotNewsEvent extends Event {

    public function show($event){
        $limit = isset($event->data['limit'])?$event->data['limit']:5;
        $hotNewsDataProvider = new ActiveDataProvider([
            'query' => News::find()->limit($limit),
        ]);
        $hotNews = $hotNewsDataProvider->getModels();
        foreach ($hotNews as $news){
            echo $news->id;
        }
        
    }
}