<?php

use yii\db\Migration;

/**
 * Handles the creation for table `recommend_news`.
 */
class m170222_113615_create_recommend_news_table extends Migration
{
    /**
     * @inheritdoc
     */
    public function up()
    {
        $tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
            $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }
        $this->createTable('{{%recommend_news}}', [
            'id' => $this->primaryKey(),
            'newsId' => $this->integer()->notNull(),
            'rate' => $this->integer()->notNull()->defaultValue(5),
        ],$tableOptions);
    }

    /**
     * @inheritdoc
     */
    public function down()
    {
        $this->dropTable('{{%recommend_news}}');
    }
}
