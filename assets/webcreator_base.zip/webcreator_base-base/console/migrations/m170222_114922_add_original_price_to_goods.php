<?php

use yii\db\Migration;

class m170222_114922_add_original_price_to_goods extends Migration
{
    public function up()
    {

        $this->addColumn('{{%goods}}','originalPrice','string not null');
        $this->addCommentOnColumn('{{%goods}}','originalPrice','原价');
    }

    public function down()
    {
        $this->dropColumn('{{%goods}}','originalPrice');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
