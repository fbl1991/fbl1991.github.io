<?php

use yii\db\Migration;

class m170222_113328_add_time_to_comment extends Migration
{
    public function up()
    {
        $this->addColumn('{{%comment}}','created_at','int(11) not null');
        $this->addColumn('{{%comment}}', 'updated_at','int(11) not null');

    }

    public function down()
    {
       $this->dropColumn('{{%comment}}', 'created_at');
       $this->dropColumn('{{%comment}}', 'updated_at');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
