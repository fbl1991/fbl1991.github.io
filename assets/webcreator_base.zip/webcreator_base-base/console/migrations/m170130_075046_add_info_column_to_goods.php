<?php

use yii\db\Migration;

class m170130_075046_add_info_column_to_goods extends Migration
{
    public function up()
    {

        $this->addColumn('{{%goods}}','info','text');
        $this->addCommentOnColumn('{{%goods}}','info','详细信息');
    }

    public function down()
    {
        $this->dropColumn('{{%goods}}','info');
        return true;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
