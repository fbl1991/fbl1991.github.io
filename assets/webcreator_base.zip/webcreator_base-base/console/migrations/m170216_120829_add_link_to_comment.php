<?php

use yii\db\Migration;

class m170216_120829_add_link_to_comment extends Migration
{
    public function up()
    {
        $this->addColumn('{{%comment}}','link','string');
        $this->addCommentOnColumn('{{%comment}}','link','链接');
    }

    public function down()
    {
        $this->dropColumn('{{%comment}}', 'link');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
