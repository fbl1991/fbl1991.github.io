<?php

use yii\db\Migration;

class m170126_062425_add_abstract_to_news extends Migration
{
    public function up()
    {
        $this->addColumn('{{%news}}', 'abstract', 'string(255) not null');
        $this->addCommentOnColumn('{{%news}}', 'abstract', '摘要');
    }

    public function down()
    {

        $this->dropColumn('{{%news}}', 'abstract');

        return true;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
