<?php

use yii\db\Migration;

class m170222_154437_add_save_path_to_attachments extends Migration
{
    public function up()
    {
        $this->addColumn('{{%attachments}}', 'savePath', 'string');
        $this->addCommentOnColumn('{{%attachments}}', 'savePath', '保存的路径');
    }

    public function down()
    {
        $this->dropColumn('{{%attachments}}', 'savePath');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
