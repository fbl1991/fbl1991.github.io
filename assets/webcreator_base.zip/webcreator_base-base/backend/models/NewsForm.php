<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 1/23/17
 * Time: 4:23 PM
 */

namespace backend\models;


use yii\base\Model;

class NewsForm extends Model {

    public $title;
    public $content;
    public $status;
    public $author;

}