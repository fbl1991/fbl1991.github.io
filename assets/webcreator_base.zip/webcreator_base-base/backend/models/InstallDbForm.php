<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 1/23/17
 * Time: 1:29 PM
 */

namespace backend\models;

use Yii;
use yii\db\Migration;

class InstallDbForm extends Migration {

    public function up(){
        $tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
            $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }


            //创建用户表
        $exist = Yii::$app->db->createCommand('drop table if EXISTS {{%user}}')->query();
        $this->createTable('{{%user}}', [
                'id' => $this->primaryKey(),
                'username' => $this->string()->notNull()->unique(),
                'auth_key' => $this->string(32)->notNull(),
                'password_hash' => $this->string()->notNull(),
                'password_reset_token' => $this->string()->unique(),
                'email' => $this->string()->notNull()->unique(),

                'status' => $this->smallInteger()->notNull()->defaultValue(10),
                'created_at' => $this->integer()->notNull(),
                'updated_at' => $this->integer()->notNull(),
            ], $tableOptions);

            //创建新闻
        $exist = Yii::$app->db->createCommand('drop table if EXISTS {{%news}}')->query();

        $this->createTable('{{%news}}', [
                'id' => $this->primaryKey(),
                'title' => $this->string()->notNull(),
                'author' => $this->string(32)->notNull(),
                'content' => $this->string()->notNull(),

                'status' => $this->smallInteger()->notNull()->defaultValue(0),
                'created_at' => $this->integer()->notNull(),
                'updated_at' => $this->integer()->notNull(),
            ], $tableOptions);

            //创建讨论
        $exist = Yii::$app->db->createCommand('drop table if EXISTS {{%comment}}')->query();

        $this->createTable('{{%comment}}', [
                'id' => $this->primaryKey(),
                'newsId' => $this->bigInteger()->notNull(),
                'content' => $this->string()->notNull(),
                'userId' => $this->bigInteger()->notNull(),
            ], $tableOptions);

            //创建商品
        $exist = Yii::$app->db->createCommand('drop table if EXISTS {{%goods}}')->query();

        $this->createTable('{{%goods}}', [
                'id' => $this->primaryKey(),
                'title' => $this->string()->notNull(),
                'price' => $this->string()->notNull(),
                'front_img' => $this->string()->notNull(),
                'created_at' => $this->integer()->notNull(),
                'updated_at' => $this->integer()->notNull(),
                'status' => $this->smallInteger()->notNull(),
            ], $tableOptions);
return true;
    }

}