<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/2/17
 * Time: 10:52 PM
 */

namespace backend\models;


use Yii;
use yii\base\Model;
use yii\web\ForbiddenHttpException;

class SettingsForm extends Model {

    public $webName;
    public $logo;
    public $newsSwitch;
    public $newsCommentSwitch;
    public $goodsSwitch;
    public $editor = 'ueditor';
    public $friendLinks = [];

    /**
     * 根据params初始化seetingsForm
     */
    public function init() {
        foreach ($this->attributes as $key=>$value){
            $this->{$key} = isset(Yii::$app->params[$key])?Yii::$app->params[$key]:null;
        }
    }

    public function rules() {
        return [
            ['webName','string'],
            ['friendLinks','string'],
            ['newsSwitch','boolean'],
            ['newsCommentSwitch','boolean'],
            ['goodsSwitch','boolean'],
            ['editor','in', 'range'=>['ueditor', 'redactor']],
         //   ['front_img', 'image', 'extensions' => 'jpg, jpeg, gif, png'],
        ];
    }
    /*将内容保存到params中*/
    public function save(){
        $params = array_merge(Yii::$app->params, $this->attributes);

        $paramsFile = Yii::getAlias('@common/config/params.php');

        if(is_writable($paramsFile)){
            $fp = fopen($paramsFile,'w+');
            fwrite($fp, "<?php \r\n return ");
            fwrite($fp, var_export($params, true));
            fwrite($fp, ";");
            fclose($fp);
        }else{
            throw new ForbiddenHttpException('配置文件禁止写入');
        }
        return true;

    }

    public function attributeLabels() {
        return [
            'webName' => '站点名称',
            'newsSwitch' => '新闻页面开关',
            'newsCommentSwitch' => '新闻评论页面开关',
            'goodsSwitch' => '产品页面开关',
            'editor' => '编辑器选择',
            'friendLinks' => '友情链接',
          //  'logo' => '图标',
        ];
    }



}