<?php

/* @var $this \yii\web\View */
/* @var $content string */

use backend\assets\AppAsset;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use common\widgets\Alert;

AppAsset::register($this);

\frontend\assets\MenuhoverAsset::register($this);

$this->registerJs("
    $.fn.bootstrapDropdownHover({
});
");
?>
<?php $this->beginPage() ?>
<?php $this->title = '后台管理系统';?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>
<div class="container content-body">
    <div class="rows">
        <div class="col-lg-2">
        <?php

            echo Nav::widget([
                'items' => [
                    [
                        'label' => '通用设置',
                        'url' => ['settings/index'],
                    ],
                    [
                        'label' => '新闻管理',

                        'items'=>[
                            [
                                'label' => '新建',
                                'url' => ['news/create'],
                            ],
                            [
                                'label' => '列表',
                                'url' => ['news/index'],
                            ],
                        ],
                    ],
                    [
                        'label' => '商品管理',
                        'items' => [
                            [
                                'label' => '添加',
                                'url' => ['goods/create'],
                            ],
                            [
                                'label' => '列表',
                                'url' => ['goods/index'],
                            ],
                        ],
                    ],
                    [
                        'label' => '用户管理',
                        'url' => ['user/index'],
                    ],
                    [
                        'label' => '退出',
                        'url' => ['site/logout'],
                        'visible' => !Yii::$app->user->isGuest,

                    ],
                    [
                        'label' => '登陆',
                        'url' => ['site/login'],
                        'visible' => Yii::$app->user->isGuest,

                    ],
                ],

            ]);
        ?>
        </div>
        <div class="col-lg-8">
            <?= Breadcrumbs::widget([
                'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
            ]) ?>
            <?= Alert::widget() ?>
            <?= $content ?>
        </div>
    </div>

</div>


<footer class="footer">
    <p class="pull-left">&copy; 版权所有 方源 <?= date('Y') ?></p>

</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
