<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use common\models\News;
/* @var $this yii\web\View */
/* @var $searchModel common\models\NewsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '新闻';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="news-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>


<?php Pjax::begin(); ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'title',
            'author',

            [
                'attribute'=>'status',
                'value' => function($model){
                    $status = [
                        News::STATUS_DRAFT => '草稿',
                        News::STATUS_PUBLISH => '已发表',
                    ];
                    return $status[$model->status];
                },
                'filter' => [
                    News::STATUS_DRAFT => '草稿',
                    News::STATUS_PUBLISH => '已发表',
                ],

            ],

            // 'created_at',
             [
                 'attribute'=>'updated_at',
                'format'=>['date', 'php:Y-m-d'],
             ],

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
<?php Pjax::end(); ?>
</div>
