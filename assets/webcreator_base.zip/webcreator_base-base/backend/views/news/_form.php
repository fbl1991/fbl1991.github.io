<?php

use common\widgets\ImageUpload\ImageUpload;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\models\News;

/* @var $this yii\web\View */
/* @var $model common\models\News */
/* @var $form yii\widgets\ActiveForm */

?>

<div class="news-form">

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>

    <?= ImageUpload::widget([
            'form' => $form,
            'model' => $model,
            'attribute' => 'frontImg',
        ])
    ?>
    <?php /* echo $form->field($model, 'frontImg')->fileInput(['accept' => 'image/*', 'id'=>'upload-image']) ?>

    <?= Html::img($model->getThumbUploadUrl('frontImg', 'preview'), ['class' => 'upload-preview','id'=>'upload-preview']) */?>

    <?= $form->field($model, 'abstract')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'author')->textInput(['maxlength' => true]) ?>
    <?php if(isset(Yii::$app->params['editor']) && Yii::$app->params['editor'] == 'ueditor'){ ?>

         <?= $form->field($model,'content')->widget('kucha\ueditor\UEditor',[]); ?>

    <?php }else{ ?>
        <?= $form->field($model, 'content')->widget(\yii\redactor\widgets\Redactor::className(),[
            'clientOptions' => [
                //'imageManagerJson' => ['/redactor/upload/image-json'],
                //'imageUpload' => ['/redactor/upload/image'],
                //'fileUpload' => ['/redactor/upload/file'],
                'lang' => 'zh_cn',
                'plugins' => ['clips', 'fontcolor','imagemanager']
            ]
        ])?>
    <?php }?>
    <?= $form->field($model, 'status')->dropDownList([News::STATUS_DRAFT => '未发表',News::STATUS_PUBLISH=>'发表']) ?>


    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? '创建' : '更新', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
