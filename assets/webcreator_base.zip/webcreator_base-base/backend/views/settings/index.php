<?php

use backend\assets\SwitchAsset;
use yii\helpers\Html;
use yii\web\View;
use yii\widgets\ActiveForm;


/* @var $this yii\web\View */
/* @var $model common\models\model */
/* @var $form yii\widgets\ActiveForm */
?>
<?php $this->beginBlock('js'); ?>

    $(function () {
        $('#news-form').on('beforeSubmit', function (e) {
            var $form = $(this);

            $.ajax({
                url: $form.attr('action'),
                type: 'post',
                data: $form.serialize(),
                dataType: 'json',
                success: function (data) {
                        if(data.status == true){
                            $("#status").show(1000, function(){
                                $("#status").fadeOut("slow");
                            });

                        }else{
                            $("#status").hide();
                        }
                }
            });
        }).on('submit', function (e) {
            e.preventDefault();
        });
    });
$(".switch").bootstrapSwitch({
    size: 'mini',
    onColor: 'success',
    offColor: 'danger',
    onText: '开',
    offText: '关'
});
<?php $this->endBlock() ?>
<?php
$this->registerJs($this->blocks['js']);
SwitchAsset::register($this);
?>

<div class="news-form">

    <?php $form = ActiveForm::begin([
        'id' => 'news-form',

    ]); ?>

    <?= $form->field($model, 'webName')->textInput();?>
    <?= $form->field($model, 'editor')->radioList(['ueditor'=>'ueditor', 'redactor'=>'redactor']); ?>
    <?= $form->field($model, 'newsSwitch')->checkbox(['uncheck'=>"0",'class'=>'switch']); ?>
    <?= $form->field($model, 'newsCommentSwitch')->checkbox(['uncheck'=>"0",'class'=>'switch']); ?>
    <?= $form->field($model, 'goodsSwitch')->checkbox(['uncheck'=>"0",'class'=>'switch']); ?>

    <div class="form-group">
        <?= Html::submitButton('更新', ['class' =>  'btn btn-success']) ?>
        <span class="glyphicon glyphicon-ok" id="status" style="display: none" aria-hidden="true"></span>

    </div>

    <?php ActiveForm::end(); ?>


</div>



