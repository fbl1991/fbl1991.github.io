<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\Goods */

$this->title = $model->title;
$this->params['breadcrumbs'][] = ['label' => '商品', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="goods-view">

    <p>
        <?= Html::a('更新', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('删除', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => '该操作不可恢复,确定删除?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <h4>缩略图</h4>
    <div class="clearfix">

        <?php
        echo $this->renderAjax('@frontend/web/themes/default/goods/_goodsList.php',
            [
                'model' => $model
            ]
        );
        ?>
    </div>
    <h4>详情</h4>
    <div class="detail">

        <?php
        echo $this->renderAjax('@frontend/web/themes/default/goods/view.php',
            [
                'model' => $model
            ]
        );
        ?>
    </div>


</div>
