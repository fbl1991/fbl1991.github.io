<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/18/17
 * Time: 11:00 PM
 */

namespace backend\assets;


use yii\web\AssetBundle;

class SwitchAsset extends AssetBundle {

    public $sourcePath = '@vendor/bower/bootstrap-switch/dist';

    public $js = [
        'js/bootstrap-switch.min.js',
    ];

    public $css = [
        'css/bootstrap3/bootstrap-switch.min.css',
    ];
}