<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/2/17
 * Time: 10:44 PM
 */

namespace backend\controllers;


use backend\models\SettingsForm;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;

class SettingsController extends Controller {

    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'ruleConfig' => ['class' => 'common\filters\AccessRule'],
                'only' => ['index'],
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['index'],
                        'roles' => ['#'],
                    ],
                ],
            ],
        ];
    }

    public function actionIndex(){
        $settings = new SettingsForm();

        if(Yii::$app->request->isAjax && $settings->load(Yii::$app->request->post()) && $settings->save()){
            Yii::$app->response->format= Response::FORMAT_JSON;
            return ['status' => true];

        }
        return $this->render('index',[
            'model' => $settings,
        ]);
    }
}