<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/22/17
 * Time: 11:41 PM
 */

namespace backend\controllers;


use common\models\Attachments;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;

class AttachmentController extends Controller {

    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'ruleConfig' => ['class' => 'common\filters\AccessRule'],
                'only' => ['del'],
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['del'],
                        'roles' => ['#'],
                    ],
                ],
            ],
        ];
    }
    public function actionDel($id){
        $model = $this->findModel($id);
        $model->delete();
        Yii::$app->response->format = Response::FORMAT_JSON;
        return [
            'status' => true,
        ];
    }

    public function findModel($id){
        if (($model = Attachments::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}