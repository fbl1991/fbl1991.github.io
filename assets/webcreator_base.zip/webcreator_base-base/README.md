公司主页建站工具
===============================

该工具主要用于公司建立网站,满足小公司的建站需求。已包含公司首页、新闻发布、产品展示以及用户
管理页面。新闻发布、产品展示均可在后台添加

拥有良好的代码结构,可方便的修改,适用于不同的商业模式,如各类电商、售票系统、媒体单位、在线教育等。

安装
------------------
0. 下载yii 2等库文件
```
composer install
composer update

```
1. 修改数据库连接参数 `common/config/main-local.php`
```
'db' => [
            'class' => 'yii\db\Connection',
                                      
            'dsn' => 'mysql:host=127.0.0.1;dbname={数据库名称}', 
                                        
            'username' => '{用户名}',
            'password' => '{密码}',
            'charset' => 'utf8',
        ],
```
2. 创建表,在当前目录下运行
```
./yii migrate
```
3. 前台访问页面 `/frontend/web/`,后台访问页面`/backend/web/`
4. 在前台注册一个用户,后手动将其添加为管理员。添加管理员的过程为:在roles表中
添加`urserId`为注册用户的id,`role`为`admin`

最可能修改的文件目录
-------------------

```
common
    config/main-local.php 包含了数据库的配置信息
    upload/system        包含了一些系统图标,替换时,请保证名称与原来一致
    
backend
    assets/              包含后台的javascript和css文件,如果添加了新的
                         css或javascript请在这里添加
    views/               包含了后台的视图文件
    web/                 包含了后台的javascript与css文件
frontend
    assets/              包含后台的javascript和css文件,如果添加了新的
                          css或javascript请在这里添加
    web/                包含了前端使用的css和javascript文件
    web/themes           包含了前端使用的视图文件,如需添加新的主题,请修改这里
    
```
