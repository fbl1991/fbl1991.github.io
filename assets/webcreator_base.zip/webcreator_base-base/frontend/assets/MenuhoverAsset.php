<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/27/17
 * Time: 8:42 PM
 */

namespace frontend\assets;


use yii\web\AssetBundle;

class MenuhoverAsset extends AssetBundle {

    public $sourcePath = '@vendor/bower/bootstrap-dropdown-hover/dist';

    public $js = [
        'jquery.bootstrap-dropdown-hover.min.js',
    ];

}