<?php
/* @var $this yii\web\View */

use common\component\Hook;
use yii\base\Event;

$this->title = $model->title;
$this->registerCssFile('@frontendurl/web/css/news.css');
?>



<div class="news-pad">
    <h1 class="news-header"><?=$model->title;?></h1>
    <div class="news-author">
        <span>编辑: <?= $model->editor->username?></span>
        <span>作者: <?= $model->author?></span>
        <span>更新时间: <?=date('Y-m-d',$model->created_at);?></span>
    </div>
    <div class="news-body">
        <?php
            echo $model->content;
        ?>
    </div>

</div>
<?php
    Event::trigger(Hook::className(), Hook::NEWS_DISCUSSION);
?>