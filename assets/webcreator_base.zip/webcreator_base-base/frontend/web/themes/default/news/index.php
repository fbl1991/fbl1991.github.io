<?php
/* @var $this yii\web\View */
use common\component\Hook;
use yii\base\Event;
use yii\widgets\ListView;

$this->title = '新闻';
$this->registerCssFile('@frontendurl/web/css/news.css');
?>

<div class="col-lg-8">
    <div class="news-latest">最新资讯</div>
    <?= ListView::widget([
        'dataProvider' => $dataProvider,
        'emptyText' => '还没有大事儿发生……',
        'itemView' => '_newsList',
        'summary' => '',
    ]);?>
</div>

    <?php
        Event::trigger(Hook::className(), Hook::NEWS_HOT);
        Event::trigger(Hook::className(), Hook::NEWS_PROPOSE);
    ?>





