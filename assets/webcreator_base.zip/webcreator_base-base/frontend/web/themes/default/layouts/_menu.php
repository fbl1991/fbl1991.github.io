<?php

/* @var $this \yii\web\View */
/* @var $content string */

use common\models\Comment;
use yii\data\ActiveDataProvider;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;

\frontend\assets\MenuhoverAsset::register($this);

$this->registerJs("
    $.fn.bootstrapDropdownHover({
});
");
NavBar::begin([
    'brandLabel' => '<div class="col-lg-2 col-sm-2">' . Html::img(Yii::getAlias('@commonurl/upload/system/weblogo.png'),
            ['class'=>'img-rounded img-responsive']) .'</div>',
    'brandUrl' => Yii::$app->homeUrl,
    'options' => [
        'class' => 'navbar navbar-default navbar-static-top',

    ],
]);

$menuItems =[];
$menuItems[] = ['label' => '首页', 'url' => ['site/index']];
if(isset(Yii::$app->params['newsSwitch']) && Yii::$app->params['newsSwitch']==1){
    $menuItems[] = ['label' => '新闻', 'url' => ['news/index']];
}
if(isset(Yii::$app->params['goodsSwitch']) && Yii::$app->params['goodsSwitch']==1){
    $menuItems[] = ['label' => '产品', 'url' => ['goods/index']];
}
$menuItems[] = ['label' => '关于我们', 'url' => ['/site/about']];
if(!Yii::$app->user->isGuest){
    $unreceivedComments = new ActiveDataProvider([
        'query' => Comment::find()->where(['sendStatus'=>Comment::SENDSTATUS_UNRECEIVED, 'receiverId' => Yii::$app->user->id])
            ->andWhere(['not', ['senderId' => Yii::$app->user->id]]),
    ]);

    $menuItems[] = ['label' => '消息'.($unreceivedComments->totalCount ? $unreceivedComments->totalCount:''),
        'items'=>[
            [
                'label' => '未读消息',
                'url' => ['comment/unread'],
            ],
            [
                'label' => '往期消息',
                'url' => ['comment/index'],
            ],
        ],
        ];
}

if (Yii::$app->user->isGuest) {
    $menuItems[] = ['label' => '注册', 'url' => ['/site/signup']];
    $menuItems[] = ['label' => '登陆', 'url' => ['/site/login']];
} else {
    $menuItems[] = '<li>'
        . Html::beginForm(['/site/logout'], 'post')
        . Html::submitButton(
            '退出 (' . Yii::$app->user->identity->username . ')',
            ['class' => 'btn btn-link']
        )
        . Html::endForm()
        . '</li>';
}
echo Nav::widget([
    'options' => ['class' => 'navbar-nav navbar-right'],
    'items' => $menuItems,
]);
NavBar::end();
?>
