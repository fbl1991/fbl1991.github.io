<?php

/* @var $this yii\web\View */

use yii\bootstrap\Html;

$this->title = 'My Yii Application';
?>

<div class="jumbotron">
    <div class="container">
        <h1>解决搭建公司网站的烦恼!</h1>

        <p class="lead">你还在为搭建公司网站而烦恼吗?WebCreator为此而生。</p>
        <p>费用少、性能稳、可定制</p>


        <p><a class="btn btn-lg btn-success" href="">获取它!</a></p>
    </div>

</div>

<div class="jumbotron" style="background-color:rgb(240,240,240)">
    <div class="container">
        <h1>WebCreator是什么?</h1>
        <p>WebCreator是一款基于性能优越的Yii 2.0而构建的公司主页搭建工具,它实现了四个基本功能:</p>
        <div class="row">
            <div class="col-lg-3">
                <span class="glyphicon glyphicon-home" style="color: rgb(255, 140, 60); font-size: 57px;" aria-hidden="true"></span>
                <h2>首页</h2>
                <p>宣传您公司主旨,为您的事业而呐喊</p>
            </div>
            <div class="col-lg-3">
                <span class="glyphicon glyphicon-list-alt" style="color: rgb(84, 212, 131); font-size: 57px;" aria-hidden="true"></span>
                <h2>新闻</h2>
                <p>展示您公司的动态,新闻可在后端很方便的添加,且注册的用户可评论您的新闻</p>
            </div>
            <div class="col-lg-3">
                <span class="glyphicon glyphicon-apple" style="color: rgb(110, 114, 242); font-size: 57px;" aria-hidden="true"></span>
                <h2>产品</h2>
                <p>展示您公司的产品,产品可以在后端方便添加</p>
            </div>
            <div class="col-lg-3">
                <span class="glyphicon glyphicon-user" style="color: rgb(155, 159, 14); font-size: 57px;" aria-hidden="true"></span>
                <h2>用户</h2>
                <p>用于收集关注您的用户的信息</p>
            </div>
        </div>
    </div>
</div>



<div class="jumbotron">
    <div class="container">
    <h1>如何获得它?</h1>
    <div class="row">
        <div class="col-lg-9">
            <p>WebCreator是一款开源软件,具体的许可请参见license,仅需要少量的费用即可用于商业。</p>
        </div>
        <div class="col-lg-3">
            <?= Html::img(Yii::getAlias('@sysimg/contact.png'),['class'=>'img-responsive'])?>
            微信扫描二维码,与我们联系
        </div>
    </div>
    </div>

</div>

<div class="jumbotron"  style="background-color:rgb(240,240,240)">
    <div class="container">
        <h1>定制服务</h1>
        <p>满足您的个性化需求。通常包括:1、个性化的主题。2、添加适于您商业需求功能</p>
    </div>
</div>

<div class="jumbotron home-footer" style="background-color: rgb(30, 30, 30); color: rgb(100, 100, 100) ">
    <div class="container">
        <p>
            <?=Html::a('首页',Yii::$app->homeUrl)?>
        </p>

        <p>
            <?=Html::a('Yii','http://www.yiiframework.com/')?>
        </p>

        <p>© <?= date('Y')?> 西河科技</p>
    </div>
</div>
