<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = '关于我们';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="container site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>这是关于公司介绍的页面,您可以根据自己的需要去修改下面这个文件的内容:</p>

    <code><?= __FILE__ ?></code>
</div>
