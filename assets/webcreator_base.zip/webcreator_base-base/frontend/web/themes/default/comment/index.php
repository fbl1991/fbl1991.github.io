<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/18/17
 * Time: 11:30 AM
 */

use yii\widgets\ListView;

echo ListView::widget([
    'dataProvider' => $dataProvider,
    'itemView' => '_detail',
]);