<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 1/26/17
 * Time: 8:01 PM
 */
use yii\bootstrap\Html;
use yii\helpers\Url;

?>
<div class="panel panel-default" id="<?= 'comment-id-'.$model->id?>">


<div class="panel-heading">
    <div class=" text-warning">
        <div class="panel-title">
            <span><?= Html::encode($model->sender->username);?></span>
            <span><?= date('Y-m-d h:i:s', $model->created_at)?></span>
        </div>

        <div class="pull-right">
            <?php
            if(!Yii::$app->user->isGuest){
                if($model->senderId == Yii::$app->user->id){
                    $url = Url::to(['comment/delete-comment','id'=>$model->id]);
                    echo Html::a('删除','#',[
                        'onclick'=>"
                            if (confirm('确定删除?')) {
                                $.ajax('$url', {
                                    type: 'POST'
                                }).done(function(data) {
                                    $.pjax.reload({container:\"#comments\"});
                                });
                            }
                            return false;
                        ",
                    ]);
                }else {
                    echo Html::a('回复','',[
                        'onclick' => "
                            $('#comment-content').focus().attr('placeholder','回复 {$model->sender->username} :');
                            $('#comment-receiver').val('{$model->senderId}');
                                              
                        ",
                    ]);
                }

            }
            ?>
        </div>
    </div>

</div>

<div class="panel-body">
    <?php
        if($model->senderId != $model->receiverId){
            echo '回复' . Html::encode($model->receiver->username) . ':';
        }
        echo Html::encode($model->content);
    ?>

</div>
</div>


