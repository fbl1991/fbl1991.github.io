<div class="rows news-comment">

    <?php

    use common\models\Comment;
    use yii\bootstrap\ActiveForm;
    use yii\bootstrap\Html;
    use yii\widgets\ListView;
    use yii\widgets\Pjax;

    Pjax::begin(['id'=>'comments','enablePushState' => false]);
    ListView::begin([
        'id' => 'comments',
        'dataProvider' => new \yii\data\ArrayDataProvider(['models'=>$model->comments]),
        'emptyText' => '还没有评论……',
        'itemView' => '_commentList',
        'summary' => '',
    ]);
    ListView::end();
    Pjax::end();
    ?>
    <div class="add-comment">
        评论
        <?php

        $comment = new Comment();
        $form = ActiveForm::begin([
            'action'=>['comment/add'],
            'id'=>'comment-form',
            'enableClientValidation'=>false,
        ]);
        echo $form->field($comment, 'ownerId')->hiddenInput(['value' => $model->identityId])->label(false);
        echo $form->field($comment, 'link')->hiddenInput(['value' => Yii::$app->request->getUrl()])->label(false);
        echo $form->field($comment, 'receiverId')->hiddenInput(['value' => $model->userId,'id'=>'comment-receiver'])->label(false);
        if(Yii::$app->user->isGuest){
            echo $form->field($comment, 'content')->textarea(['maxlength' => 200,
                'id'=>'comment-content','placeholder'=>'发表评论请登陆。','disabled'=>true,])->label(false);
        }else{
            echo $form->field($comment, 'content')->textarea(['maxlength' => 200,
                'id'=>'comment-content','placeholder'=>'至多200字'])->label(false);
        }

        ?>

        <div class="form-group">
            <?= Html::submitButton('确定', ['class' => 'btn btn-primary', 'name' => 'signup-button',
                'disabled'=> Yii::$app->user->isGuest]) ?>
        </div>

        <?php
        ActiveForm::end();

        ?>
    </div>
</div>