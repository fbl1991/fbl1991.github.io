<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 2/13/17
 * Time: 8:58 PM
 */
use common\models\Comment;
$this->registerCssFile('@frontendurl/web/css/comment.css');
?>
<div class="comments">
    <div class="comments-list" onclick="window.open('<?= $model->link . "#comment-id-". $model->id?>')">

        <span class="h5" >
                <?php echo $model->sender->username;?>:
        </span>
        <?= $model->content ?>
    </div>

</div>
