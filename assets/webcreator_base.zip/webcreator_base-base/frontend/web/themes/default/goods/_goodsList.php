<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 1/30/17
 * Time: 3:35 PM
 */

use yii\bootstrap\Html;
use yii\helpers\Url;

$this->registerCssFile('@frontendurl/web/css/goods.css');
?>

<div class="col-md-4 col-sm-6 goods-list">
    <div class="thumbnail">
        <?= Html::img($model->getThumbUploadUrl('front_img','preview'), ['class' => 'img-rounded img-responsive']);?>
    </div>
    <div class="caption">
        <h4> <?= $model->title  ?></h4>
        <p>
            <?= $model->briefIntro ?>
        </p>
        <p>
            <a href="<?=Url::to(['goods/view','id'=>$model->id])?>" class="btn btn-success" role="button">查看详情</a>

            <span class="goods-price">&#65509; <?=$model->price?> </span>
            <?php
            if(!empty($model->originalPrice)){
                echo '<span class="goods-original-price">&#65509;' .$model->originalPrice.'</span>';
            }
            ?>
        </p>
    </div>

</div>




