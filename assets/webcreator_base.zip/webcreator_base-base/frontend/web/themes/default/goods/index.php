<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 1/30/17
 * Time: 3:31 PM
 */

use yii\widgets\ListView;

$this->title = '商品';
?>

<div class="row">
    <?php echo ListView::widget([
        'dataProvider' => $dataProvider,
        'emptyText' => '还没有产品上架……',
        'itemView' => '_goodsList',
        'summary' => '',
    ]);
    ?>
</div>


