<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 1/30/17
 * Time: 4:05 PM
 */
use common\component\Hook;
use yii\base\Event;
use yii\helpers\Html;

$this->title = '商品-'.$model->title;
$this->registerCssFile('@frontendurl/web/css/goods.css');
?>

<div class="row">
    <?= $model->info?>
</div>

    <?php if(!empty($model->attachments)){ ?>
<div class="row goods-attachments-pad">
    <?php
        echo '附件';
        foreach ($model->attachments as $attachment){
            echo Html::a($attachment->fileName, $model->getFilesUrl($attachment->url), ['class'=>'goods-attachments']);
        }
    ?>
</div>
    <?php } ?>

<?php
Event::trigger(Hook::className(), Hook::NEWS_DISCUSSION);
?>




