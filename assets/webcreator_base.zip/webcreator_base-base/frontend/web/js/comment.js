/**
 * 评论功能
 */
$('#comment-form').on('beforeSubmit', function (e) {
    var $form = $(this);
    $.ajax({
        url: $form.attr('action'),
        type: 'post',
        data: $form.serialize(),
        dataType: 'json',
        success: function (data) {
            if(data.status == true){
                $.pjax.reload({container:"#comments"});
                $('#comment-content').val('').focus();
            }else{
                //$("#status").hide();
            }
        }
    });
}).on('submit', function (e) {
    e.preventDefault();
});

/**
 * 当光标从评论框移开时,将状态恢复
 */
$("#comment-content").focusout(function(){

    if($.trim($("#comment-content").val()) == ""){

        $("#comment-receiver").val("<?= $model->user->id ?>");
        $("#comment-content").attr("placeholder","至多200字").val("");
    }

});
