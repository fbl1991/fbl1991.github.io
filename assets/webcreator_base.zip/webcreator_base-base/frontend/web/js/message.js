/**
 * 消息模块
 *
 * Created by fbl on 2/16/17.
 */
(function ($) {

    function getAllMessage() {

        $.ajax();
    }

})($);