/**
 *
 * Created by fbl on 2/19/17.
 */

(function($){

    $.fn.bootstrapDropdownHover({
        // see next for specifications
    });

}(jQuery));