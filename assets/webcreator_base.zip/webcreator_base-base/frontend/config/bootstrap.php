<?php
use common\component\Hook;
use common\plugins\HotNewsEvent;
use common\plugins\NewsEvent;
use common\plugins\Test;
use yii\base\Event;

//Event::on(Hook::className(),Hook::TEST,[new Test(), 'hello']);

//Event::on(Hook::className(),Hook::NEWS_HOT, [new HotNewsEvent(), 'show'], ['limit'=>5]);