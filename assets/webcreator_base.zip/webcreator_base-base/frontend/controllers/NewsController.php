<?php

namespace frontend\controllers;

use common\actions\AddCommentAction;
use common\actions\DeleteCommentAction;
use Yii;
use common\models\Comment;
use common\models\News;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\web\NotFoundHttpException;

class NewsController extends \yii\web\Controller
{
    public $layout = 'main-width-8';

    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow'=>true,
                        'actions' => ['view','index'],
                    ],

                ],
            ],
        ];
    }


    /**
     * 获取新闻列表
     * @return string
     */
    public function actionIndex()
    {
        $query = News::find()->where(['status' => News::STATUS_PUBLISH]);
        $newsDataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 10,
            ],
            'sort' => [
                'defaultOrder' => [
                    'created_at' => SORT_DESC
                ],
            ],
        ]);
        return $this->render('index',[
            'dataProvider' => $newsDataProvider,
        ]);
    }

    public function actionView($id)
    {
        $model = static::loadModel($id);
        return $this->render('view',[
            'model' => $model,
            ]);
    }


    public static function loadModel($id){

        $model = News::findOne(['id'=>$id]);

        if($model !== null){
            return $model;
        } else {
            throw new NotFoundHttpException('页面去火星了~ ');
        }
    }

}
