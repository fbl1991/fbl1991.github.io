<?php
/**
 * Created by PhpStorm.
 * User: fbl
 * Date: 1/30/17
 * Time: 3:29 PM
 */

namespace frontend\controllers;


use common\models\Goods;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

class GoodsController extends Controller {

    public $layout = 'main-width-8';
    /**
     *   获得产品列表
     * @return string
     */
    public function actionIndex(){
        $query = Goods::find()->where(['status' => Goods::STATUS_PUBLISH]);
        $goodsDataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 10,
            ],
            'sort' => [
                'defaultOrder' => [
                    'created_at' => SORT_DESC
                ],
            ],
        ]);
        return $this->render('index',[
            'dataProvider' => $goodsDataProvider,
        ]);
    }

    public function actionView($id){

        $model = static::loadModel($id);
        return $this->render('view',[
            'model' => $model,
        ]);
    }

    public static function loadModel($id){
        $model = Goods::findOne(['id'=>$id]);

        if($model !== null){
            return $model;
        } else {
            throw new NotFoundHttpException('喵,没找到页面~ ');
        }
    }

}